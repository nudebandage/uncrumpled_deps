# THIS FILE IS GENERATED FROM KIVY SETUP.PY
__version__ = '1.9.2.dev0'
__hash__ = '09ee4b5e6f91d722b535623a05ea2504cc000045'
__date__ = '20170416'
